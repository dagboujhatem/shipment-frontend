export const languages=[
    "en",
    "fr",
    "es",
    "cn"
];
export const langInfo = [
    {name:"en",flag:"assets/flags/gb.svg",alias:"English"},
    {name:"fr",flag:"assets/flags/gf.svg",alias:"Français"},
    {name:"es",flag:"assets/flags/es.svg",alias:"Español"},
    {name:"cn",flag:"assets/flags/cn.svg",alias:"中文"},
  ];
