import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-header-dropdown-account',
  templateUrl: './default-header-dropdown-account.component.html',
})
export class DefaultHeaderDropdownAccountComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
