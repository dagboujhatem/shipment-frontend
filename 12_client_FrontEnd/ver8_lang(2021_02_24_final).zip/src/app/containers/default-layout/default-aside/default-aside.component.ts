import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-aside',
  templateUrl: './default-aside.component.html',
  styleUrls: ['./default-aside.component.scss'],
})
export class DefaultAsideComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
