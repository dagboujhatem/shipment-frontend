export const recentOrdersData = [
    {
        id: 1,
        clientName: 'John DOE',
        product: 2,
        date: "12/09/2020",
        state: "Receiving",
        search: ""
    },
    {
        id: 2,
        clientName: 'John DOE',
        product: 2,
        date: "12/09/2020",
        state: "Created",
        search: ""
    },
    {
        id: 3,
        clientName: 'John DOE',
        product: 2,
        date: "12/09/2020",
        state: "Created",
        search: ""
    },
    {
        id: 4,
        clientName: 'John DOE',
        product: 2,
        date: "12/09/2020",
        state: "Completed",
        search: ""
    },
    {
        id: 5,
        clientName: 'John DOE',
        product: 2,
        date: "12/09/2020",
        state: "Receiving",
        search: ""
    }
];
export const bestsellersData = [
    {
        id: 1,
        productName: 'Samsung Galaxy s21',
        quentity: 2,
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 2,
        productName: 'Samsung Galaxy s21',
        quentity: 2,
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 3,
        productName: 'Samsung Galaxy s21',
        quentity: 2,
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 4,
        productName: 'Samsung Galaxy s21',
        quentity: 2,
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 5,
        productName: 'Samsung Galaxy s21',
        quentity: 2,
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
];
export const stocksData = [
    {
        id: 1,
        productName: 'Samsung Galaxy s21',
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 2,
        productName: 'Samsung Galaxy s21',
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 3,
        productName: 'Samsung Galaxy s21',
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 4,
        productName: 'Samsung Galaxy s21',
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
    {
        id: 5,
        productName: 'Samsung Galaxy s21',
        sku: "XFFDFDFDF",
        barcode: "845653465344232",
        search: ""
    },
];