export const shipmentsChartData={
    barChartLabels:[
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ],
      barChartData:[
        { data: [10, 15, 23, 34, 56, 80, 123,156,176,189,181,210], 
          label: 'Shipments' ,
          backgroundColor: '#5983FF',
          hoverBackgroundColor: '#3c6dff',
        }
      ]
}