export interface IInvoiceData {
  number: string;
  period: string;
  amount: string;
  dueDate: string;
  invoice: string;
  details: string;
}
export const invoiceData: IInvoiceData[] = [
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
  {
    number: "000014875",
    period: "31/08/2020",
    amount: "3500.00",
    dueDate: "03/08/2020",
    invoice: "",
    details: "",
  },
];
