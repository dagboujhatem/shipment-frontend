export interface IInventoryData {
  sku: string;
  productName: string;
  availableStock: number;
  reservedStock: number;
}

export const inventoryData: IInventoryData[] = [
  {
  sku: '694103423545342',
  productName: 'Xiaomi RedMi Note 8 pro Bleu',
  availableStock:0,
  reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '56703423545342',
    productName: 'Xiaomi RedMi Note 8 pro Gley',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
  },
  {
    sku: '694103423545342',
    productName: 'Xiaomi RedMi Note 8 pro Bleu',
    availableStock:0,
    reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
    },
    {
      sku: '694103423545342',
      productName: 'Xiaomi RedMi Note 8 pro Bleu',
      availableStock:0,
      reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      },
      {
        sku: '694103423545342',
        productName: 'Xiaomi RedMi Note 8 pro Bleu',
        availableStock:0,
        reservedStock:0,
      }
];
