export const trackData:any = [
    {num:1,date:"01/01/2020"},
    {num:2,date:"01/01/2020"},
    {num:3,date:"01/01/2020"},
    {num:4,date:"01/01/2020"},
  ];
export const shipmentContents:any=[
    {
      MSKU:"9V-MVES-01KW",
      Title:"Samsung Galaxy A20e White",
      SubTitle:"Size:Standard-Size EAN:8801212123",
      Shipped:15,
      Received:15
    },
    {
      MSKU:"9V-MVES-01KW",
      Title:"Samsung Galaxy A20e White",
      SubTitle:"Size:Standard-Size EAN:8801212123",
      Shipped:15,
      Received:15
    },
    {
      MSKU:"9V-MVES-01KW",
      Title:"Samsung Galaxy A20e White",
      SubTitle:"Size:Standard-Size EAN:8801212123",
      Shipped:15,
      Received:15
    },
    {
      MSKU:"9V-MVES-01KW",
      Title:"Samsung Galaxy A20e White",
      SubTitle:"Size:Standard-Size EAN:8801212123",
      Shipped:15,
      Received:15
    },
    {
      MSKU:"9V-MVES-01KW",
      Title:"Samsung Galaxy A20e White",
      SubTitle:"Size:Standard-Size EAN:8801212123",
      Shipped:15,
      Received:15
    },
  ];